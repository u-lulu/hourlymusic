this mod plays the animal crossing gamecube hourly music in real-time adds 24 music tracks, these tracks change every real-time hour!

more osts will be added in the near future!

All rights to the music used belong to their respective owners. I do not claim ownership over any content used.
Animal Crossing is owned by Nintendo. These tracks can be removed upon legitimate request.
